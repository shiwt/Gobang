/* date:2018/6/26
 * creater:wt_shi
 * note:主方法类，程序的运行入口。对窗体进行一些设置
 * */
package swt.test;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class MainTest extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private DrawChessBoard drawChessBoard;
	public MainTest() {		//构造函数
		drawChessBoard = new DrawChessBoard(); //创建DrawChessBoard实例
		//Frame标题
		setTitle("单机五子棋");
		//将drawChessBoard组建添加到容器中
		Container containerPane = this.getContentPane();
		containerPane.add(drawChessBoard);	
		
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();//获取屏幕尺寸对象
		this.setSize(532, 555);////设置当前窗体的尺寸大小（或者700*600  539*562）
		Dimension myframe=this.getSize();//获取当前窗体的尺寸对象
		int w=(screen.width-myframe.width)/2;//水平位置
		int h=(screen.height-myframe.width)/2;//垂直位置
		this.setLocation(w,h);//设置窗体出现位置
		this.setResizable(false);//使窗体不可最大化
		//为了防止内存泄漏，设置窗口关闭按钮的默认操作(点击关闭时退出进程)
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	}
	public static void main(String[] args) {
		MainTest m = new MainTest();
		m.setVisible(true);//使窗体显示
	}

}
