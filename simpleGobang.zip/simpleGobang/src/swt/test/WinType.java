package swt.test;
//获胜方式
public class WinType {
	private boolean useC;//获胜方式对电脑是否有效。true:有效,false:无效
	private boolean useP;//获胜方式对玩家是否有效。true:有效,false:无效
	private int[] winX;//记录获胜情况的五颗棋子的x坐标
	private int[] winY;
	private int[] isH;//记录是否有连子，即五个位置是否有子。有子的话电脑落子为1，玩家落子为2
	public WinType()
	{
		this.useC = true;
		this.useP = true;
		this.winX = new int[5];
		this.winY = new int[5];
		this.isH = new int[5];
	}

	public boolean isUseC() {
		return useC;
	}

	public void setUseC(boolean useC) {
		this.useC = useC;
	}
	
	public boolean isUseP() {
		return useP;
	}

	public void setUseP(boolean useP) {
		this.useP = useP;
	}

	public int[] getWinX() {
		return winX;
	}

	public void setWinX(int[] winX) {
		this.winX = winX;
	}

	public int[] getWinY() {
		return winY;
	}

	public void setWinY(int[] winY) {
		this.winY = winY;
	}

	public int[] getIsH() {
		return isH;
	}

	public void setIsH(int[] isH) {
		this.isH = isH;
	}
	
}
