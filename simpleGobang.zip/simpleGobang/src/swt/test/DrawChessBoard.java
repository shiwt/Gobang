/* date:2018/6/26
 * creater:wt_shi
 * note:画棋盘类，这里实现加载背景图片，画棋盘线和棋子，监听鼠标点击事件等。
 * */
package swt.test;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;

import javax.swing.JPanel;

public class DrawChessBoard extends JPanel implements MouseListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Image image;//背景图片
	private final static int ROWS = 19;//19*19的棋谱
	public static ChessFlag[][] chessFlagsArr = new ChessFlag[ROWS][ROWS];//棋盘
	public static int flag = 1;//标志位，玩家与电脑交叉下棋
	public static Point lastPoint;//记录最新一个落子的位置
	public DrawChessBoard()
	{
		//String url = "res/images/chessborad.png";
		//为了打包成可运行文件时能把图片包含进去,只在本地运行上面那样写比较简单
		URL url = this.getClass().getClassLoader().getResource("images/chessborad.png");
		this.image = Toolkit.getDefaultToolkit().getImage(url);
		if(null == image)
		{
			System.err.println("image is not exist");
		}
		addMouseListener(this);//将监听事件注册到组件
		lastPoint = new Point();
	}
	/*重写paintComponent方法，实现JPanel加背景，画线等功能
	  此方法是自动执行的，执行完构造函数后，自动执行。   当java认为需要重新绘制组件的时候由java调用。
　　例如在程序中repaint();或者程序窗口最小化，然后恢复。或者程序窗口被遮挡，又显现的时候。
	*/
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		//获取图片长宽(524*524)
		int imgWidth = this.image.getWidth(this);
		int imgHeight = this.image.getHeight(this);
		//获取JPanel宽高
		int FWidth = this.getWidth();  
        int FHeight= this.getHeight(); 
        //绘制图片
        int x=(FWidth-imgWidth)/2;  
        int y=(FHeight-imgHeight)/2;
        g.drawImage(image, x, y,null);
        
        int span_x = (imgWidth-20)/(ROWS-1);
        int span_y = (imgHeight-20)/(ROWS-1);//横向纵向间隔相同，这里以及下面用到时不再区分
        //System.out.println("span_x "+span_x+"  span_y "+span_y);
        
        //画横线
        for(int i = 0;i<ROWS;i++)
        {
        	g.drawLine(x+10, y+10+i*span_y, x+imgWidth-10, y+10+i*span_y);
        }
        //画竖线
        for(int i = 0;i<ROWS;i++)
        {
        	g.drawLine(x+10+i*span_x, y+10, x+10+i*span_x, y+imgHeight-10);
        }
        
        //绘制棋子。遍历二维数组，调用绘制棋子函数。
        for(int i = 0;i<ROWS;i++)
        {
        	for(int j = 0;j<ROWS;j++)
        	{
        		if(chessFlagsArr[i][j] != null && chessFlagsArr[i][j].isPlaced() == true)
        		{
        			drawFlag(i,j,chessFlagsArr[i][j],span_x,g);//调用绘制棋子函数
        		}
        	}
        }
	}
	
	//根据位置画棋子.x,y是指棋子的位置，19*19的交叉点的哪一点；interval：棋盘线之间的间隔.这里纵横间隔相同不再区分
	protected void drawFlag(int x,int y,ChessFlag chessFlag,int interval,Graphics g)
	{
		if(chessFlag.getFlagColor()==1)//如果是黑子
		{
			g.setColor(Color.BLACK);//画笔颜色设置成黑色
			/*第一个交叉点(旗子落点)的矩形坐标是：(15-interval/2,15-interval/2)，所以第i,j个交叉点的
			 * 坐标是(15-interval/2+i*interval,15-interval/2+j*interval)，圆形的长宽当为interval-10,较为美观
			 * 这里棋子圆的长宽统一为interval-10*/
			g.drawOval(15-interval/2+x*interval, 15-interval/2+y*interval, interval-10, interval-10);
	        g.fillOval(15-interval/2+x*interval, 15-interval/2+y*interval, interval-10, interval-10);
		}
		else//如果是白子
		{
			g.setColor(Color.WHITE);//画笔颜色设置成白色
			/*如果按照上面绘制黑子的方法，会出现白色填充和黑色的边框。这里适当调整1,2个像素，使白子没有黑色边框*/
			g.drawOval(15-interval/2+x*interval, 15-interval/2+y*interval, interval-10, interval-10);
	        g.fillOval(15-interval/2+x*interval-1, 15-interval/2+y*interval-1, interval-8, interval-8);
		}
		//给最新一个落子周边画上框
		if(lastPoint.getX()!=-1 && lastPoint.getY()!=-1)
		{
			g.setColor(Color.MAGENTA);//设置颜色为品红色
			Graphics2D g2 = (Graphics2D)g;  //g是Graphics对象
			g2.setStroke(new BasicStroke(2.0f));//设置线宽
			int lastX = lastPoint.getX();
			int lastY = lastPoint.getY();
			int halfInterval = (interval-10)/2;
			int lineDis = 4;
			g.drawLine(lastX*interval+10-halfInterval-2,lastY*interval+10-halfInterval-2,lastX*interval+10-halfInterval-2+lineDis,lastY*interval+10-halfInterval-2);
			g.drawLine(lastX*interval+10+halfInterval+2-lineDis,lastY*interval+10-halfInterval-2,lastX*interval+10+halfInterval+2,lastY*interval+10-halfInterval-2);
			g.drawLine(lastX*interval+10-halfInterval-2,lastY*interval+10+halfInterval+2,lastX*interval+10-halfInterval-2+lineDis,lastY*interval+10+halfInterval+2);
			g.drawLine(lastX*interval+10+halfInterval+2-lineDis,lastY*interval+10+halfInterval+2,lastX*interval+10+halfInterval+2,lastY*interval+10+halfInterval+2);
			g.drawLine(lastX*interval+10-halfInterval-2,lastY*interval+10-halfInterval-2,lastX*interval+10-halfInterval-2,lastY*interval+10-halfInterval-2+lineDis);
			g.drawLine(lastX*interval+10+halfInterval+2,lastY*interval+10-halfInterval-2,lastX*interval+10+halfInterval+2,lastY*interval+10-halfInterval-2+lineDis);
			g.drawLine(lastX*interval+10-halfInterval-2,lastY*interval+10+halfInterval+2-lineDis,lastX*interval+10-halfInterval-2,lastY*interval+10+halfInterval+2);
			g.drawLine(lastX*interval+10+halfInterval+2,lastY*interval+10+halfInterval+2-lineDis,lastX*interval+10+halfInterval+2,lastY*interval+10+halfInterval+2);
		}
	}
	
	//当用户按下并松开鼠标按钮时发生  
	public void mouseClicked(MouseEvent e) {
		if(flag == 0)
		{}
		else
		{
			//获取点击处的坐标
			int point_x=e.getX();  
			int point_y=e.getY();
			int countx = 0,county = 0;//记录点击落子位置

			//获取图片长宽(524*524)
			int imgWidth = this.image.getWidth(this);
			int imgHeight = this.image.getHeight(this);

			int span_x = (imgWidth-20)/(ROWS-1);

			if(point_x<0 || point_x>imgWidth || point_y<0 || point_y>imgHeight)
			{
				System.out.println("非法点击");
			}
			else
			{
				/*点击位置要带以棋盘线交叉点为圆心，棋子圆半径为半径的圆内方才有效。也就是点击
				 * 位置的坐标，x坐标对span_x(棋盘线间隔)取余后在区间[1,19]，y同理.
				 * 这里没有取余，而是依次减span_x,因为要记录减的次数，以确定在二维数组中的位置。
				 * */
				while(point_x > span_x)
				{
					point_x -= span_x;
					countx++;
				}
				while(point_y > span_x)
				{
					point_y -= span_x;
					county++;
				}
				//判断点击位置坐标是否在合理区间内
				if(point_x >= 1 && point_x <= 19 && point_y >= 1 && point_y<= 19)
				{
					if(chessFlagsArr[countx][county]==null)
					{
						//用二维数组记录点击落子位置
						ChessFlag chessFlag = new ChessFlag(2, true,2);
						lastPoint.setX(countx);
						lastPoint.setY(county);
						chessFlagsArr[countx][county] = chessFlag;
						//新开一个线程，为了让玩家下棋之后，电脑稍等一会再落子，即实现睡眠。
						new Thread(new Runnable()
						{
							public void run() {
								repaint();//重绘该组件
								flag = 0;
								ComputerAlgotithm ca = new ComputerAlgotithm();
								if(ca.isWin(2)){
									GameOver gameOver = new GameOver("恭喜你，取得胜利！");
								}
								try {
									Thread.sleep(300);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								computerDo(ca);
							}
						}).start();
					}
				}
			}
		}
	} 
    //重写MouseListener类的抽象方法
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	
	//电脑落子
	public void computerDo(ComputerAlgotithm ca)
	{
		Point point = ca.bestPlace();
		if(point == null || point.getX()<0 || point.getY()<0 || point.getX()>ROWS || point.getY()>ROWS)
		{
			System.out.println("电脑落子位置无效！！！");
		}
		else
		{
			ChessFlag chessFlag2 = new ChessFlag(1, true,1);
			chessFlagsArr[point.getX()][point.getY()] = chessFlag2;
			lastPoint = point;
			
			repaint();
			flag = 1;
			ComputerAlgotithm ca1 = new ComputerAlgotithm();
			if(ca1.isWin(1)){
				GameOver gameOver = new GameOver("很遗憾，你输了!");
			}
		}
	}
}
