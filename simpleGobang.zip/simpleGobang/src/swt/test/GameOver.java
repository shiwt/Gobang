package swt.test;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class GameOver extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public GameOver(String str)
	{
		setTitle("游戏结束");
		JLabel label = new JLabel(str);
		//将label组建添加到容器中
		Container cp = this.getContentPane();
		JPanel panel=new JPanel();
		panel.setBorder(new EmptyBorder(20, 16, 20, 20));
		panel.add(label);
		cp.add(panel);
		
		Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();//获取屏幕尺寸对象
		this.setSize(250, 100);////设置当前窗体的尺寸大小（或者700*600  539*562）
		Dimension myframe=this.getSize();//获取当前窗体的尺寸对象
		int w=(screen.width-myframe.width)/2;//水平位置
		int h=(screen.height-myframe.width)/2;//垂直位置
		this.setLocation(w,h);//设置窗体出现位置
		this.setResizable(false);//使窗体不可最大化
		//为了防止内存泄漏，设置窗口关闭按钮的默认操作(点击关闭时退出进程)
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
}
