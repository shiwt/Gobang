/* date:2018/6/26
 * creater:wt_shi
 * note:棋子类,或者说棋盘类
 * */
package swt.test;

public class ChessFlag {
	private int flagColor;//旗子颜色。1：黑，2：白
	private boolean placed;//是否落子。
	private int flagPlayer;//落子方。1：电脑，2：玩家
	public ChessFlag(int flagColor,boolean placed,int flagPlayer)
	{
		this.flagColor = flagColor;
		this.placed = placed;
		this.flagPlayer = flagPlayer;
	}
	public int getFlagColor() {
		return flagColor;
	}
	public void setFlagColor(int flagColor) {
		this.flagColor = flagColor;
	}
	public boolean isPlaced() {
		return placed;
	}
	public void setPlaced(boolean placed) {
		this.placed = placed;
	}
	public int getFlagPlayer() {
		return flagPlayer;
	}
	public void setFlagPlayer(int flagPlayer) {
		this.flagPlayer = flagPlayer;
	}
}
