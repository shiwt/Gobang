/* date:2018/6/26
 * creater:wt_shi
 * note:电脑算法类
 * */
package swt.test;

public class ComputerAlgotithm 
{
	private final static int ROWS = 19;//19*19的棋谱
	protected int countWin ;//记录有多少种获胜情况
	protected WinType[] winTables ;//记录当前棋局下的获胜表
	public ComputerAlgotithm()
	{
		countWin = countWin();
		cainit();
	}
 	public Point bestPlace()
	{
		Point[][] pointC = null;
		pointC = scorePointC();
		//printPointArr(pointC);
		Point[][] pointP = null;
		pointP = scorePointP();
		Point maxpointC = searchMaxWeight(pointC);
		Point maxpointP = searchMaxWeight(pointP);
		if(maxpointC.getWright()>=0 && maxpointP.getWright()>=0)
		{
			if(maxpointC.getWright() > maxpointP.getWright())
				return maxpointC;
			else
				return maxpointP;
		}
		else
			return null;
	}
	public void cainit()
	{
		winTables = new WinType[countWin];
		initWinTable();
	}
	/* 计算共有多少种获胜情况 */
	public static int countWin()
	{
		int winCount = 0;
		winCount = (ROWS - 4) * ROWS * 2 + (ROWS - 4) *  (ROWS - 4) * 2;
		//System.out.println("winCount:"+winCount);
		return winCount;
	}

	//初始化获胜表
	public void initWinTable()
	{
		int count = 0;
		//横向
		for(int i = 0;i<ROWS;i++)//ROWS代表width
		{
			for (int j = 0; j < ROWS-4; j++) //ROWS代表height
			{
				WinType winType = new WinType();
				int[] wtX = winType.getWinX();
				int[] wtY = winType.getWinY();
				int[] wtH = winType.getIsH();
				for(int k = 0;k<5;k++)
				{
					wtX[k] = j+k;
					wtY[k] = i;
					initW(winType,wtH,k,wtX[k],wtY[k]);
				}
				winType.setIsH(wtH);
				winType.setWinX(wtX);
				winType.setWinY(wtY);
				winTables[count++] = winType;
			}
		}
		//纵向
		for(int i = 0;i<ROWS;i++)//ROWS代表width
		{
			for (int j = 0; j < ROWS-4; j++) //ROWS代表height
			{
				WinType winType = new WinType();
				int[] wtX = winType.getWinX();
				int[] wtY = winType.getWinY();
				int[] wtH = winType.getIsH();
				for(int k = 0;k<5;k++)
				{
					wtX[k] = i;
					wtY[k] = j+k;
					initW(winType,wtH,k,wtX[k],wtY[k]);
				}
				winType.setIsH(wtH);
				winType.setWinX(wtX);
				winType.setWinY(wtY);
				winTables[count++] = winType;
			}
		}
		//左上，右下
		for(int i = 0;i<ROWS-4;i++)//ROWS代表width
		{
			for (int j = 0; j < ROWS-4; j++) //ROWS代表height
			{
				WinType winType = new WinType();
				int[] wtX = winType.getWinX();
				int[] wtY = winType.getWinY();
				int[] wtH = winType.getIsH();
				for(int k = 0;k<5;k++)
				{
					wtX[k] = j+k;
					wtY[k] = i+k;
					initW(winType,wtH,k,wtX[k],wtY[k]);
				}
				winType.setIsH(wtH);
				winType.setWinX(wtX);
				winType.setWinY(wtY);
				winTables[count++] = winType;
			}
		}
		//左下，右上
		for(int i = 0;i<ROWS-4;i++)//ROWS代表width
		{
			for (int j = ROWS-1; j > 3; j--) //ROWS代表height
			{
				WinType winType = new WinType();
				int[] wtX = winType.getWinX();
				int[] wtY = winType.getWinY();
				int[] wtH = winType.getIsH();
				for(int k = 0;k<5;k++)
				{
					wtX[k] = j-k;
					wtY[k] = i+k;
					initW(winType,wtH,k,wtX[k],wtY[k]);
				}
				winType.setIsH(wtH);
				winType.setWinX(wtX);
				winType.setWinY(wtY);
				winTables[count++] = winType;
			}
		}
		//System.out.println("count:"+count);
	}
	//初始化某一种获胜方式
	public void initW(WinType winType,int[] wtH,int k,int x,int y)
	{
		if(DrawChessBoard.chessFlagsArr[x][y]!=null && DrawChessBoard.chessFlagsArr[x][y].isPlaced()==true)
		{
			if(DrawChessBoard.chessFlagsArr[x][y].getFlagPlayer() == 1){
				wtH[k] = 1;
				winType.setUseP(false);
			}
			if(DrawChessBoard.chessFlagsArr[x][y].getFlagPlayer() == 2) {
				wtH[k] = 2;
				winType.setUseC(false);
			}
		}
	}

	//根据获胜表，若下手为电脑，计算每点基础权重，每一点有一种获胜方式加一分
	public Point[][] scorePointC()
	{
		Point[][] scoreC = new Point[ROWS][ROWS];//point二维数组记录每个空点权重
		for(int i = 0;i<ROWS;i++)
		{
			for(int j = 0;j<ROWS;j++)
			{
				scoreC[i][j] = null;
				/* 为空格*/
				if (DrawChessBoard.chessFlagsArr[i][j] == null || DrawChessBoard.chessFlagsArr[i][j].isPlaced()==false) 
				{
					Point point = new Point();
					point.setX(i);
					point.setY(j);
					for (int k = 0; k < countWin; k++)
					{
						if (winTables[k].isUseC() == true)    /* 机器方各空格评分    */
						{
							for (int m = 0; m < 5; m++)
							{
								if (winTables[k].getWinX()[m] == i && winTables[k].getWinY()[m] == j)
								{
									point.setWright(1+point.getWright());//其他，加1分
									break;
								}
							}
						}    
					}
					scoreC[i][j] = point;
				}
			}
		}
		connect(scoreC,1);
		return scoreC;
	}

	//根据获胜表，若下手为人，计算每点基础权重
	public Point[][] scorePointP()
	{
		Point[][] scoreP = new Point[ROWS][ROWS];
		for(int i = 0;i<ROWS;i++)
		{
			for(int j = 0;j<ROWS;j++)
			{
				Point point = new Point();
				point.setX(i);
				point.setY(j);
				scoreP[i][j] = point;
				/* 为空格*/
				if (DrawChessBoard.chessFlagsArr[i][j] == null || DrawChessBoard.chessFlagsArr[i][j].isPlaced()==false) 
				{
					for (int k = 0; k < countWin; k++)
					{
						if (winTables[k].isUseP() == true)    /* 机器方各空格评分    */
						{
							for (int m = 0; m < 5; m++)
							{
								if (winTables[k].getWinX()[m] == i && winTables[k].getWinY()[m] == j)
								{
									scoreP[i][j].setWright(1+scoreP[i][j].getWright());//加1分
									break;
								}
							}
						}    
					}
				}
			}
		}
		connect(scoreP,2);
		return scoreP;
	}

	//根据连子情况，加分
	public void connect(Point[][] points,int player)
	{
		for (int k = 0; k < countWin; k++)
		{
			int[] tempArr = winTables[k].getIsH();
			int[] tempX = winTables[k].getWinX();
			int[] tempY = winTables[k].getWinY();
			//printArr(tempArr);
			if(player == 1)//电脑
			{
				if(winTables[k].isUseC() == true)
				{
					int num = searchKeyNum(tempArr,player);
					if(num == 0)//无连子
					{
						//不做处理
					}
					else if (num == 1) {//此获胜方式的五个位置上有一子,加21分
						addScore(tempArr,points,tempX,tempY,21);
					}
					else if (num == 2) {//此获胜方式的五个位置上有两子,加51分
						addScore(tempArr,points,tempX,tempY,51);
					}
					else if (num == 3) {//此获胜方式的五个位置上有三子,加201分
						addScore(tempArr,points,tempX,tempY,201);
					}
					else if (num == 4) {//此获胜方式的五个位置上有四子,加501分
						addScore(tempArr,points,tempX,tempY,501);
					}
					else {//
						//GameOver gameOver = new GameOver("很遗憾，你输了!");
					}
				}
			}
			else//玩家
			{
				if(winTables[k].isUseP() == true)
				{
					int num = searchKeyNum(tempArr,player);
					if(num == 0)//无连子
					{
						//不做处理
					}
					else if (num == 1) {//此获胜方式的五个位置上有一子,加20分
						addScore(tempArr,points,tempX,tempY,20);
					}
					else if (num == 2) {//此获胜方式的五个位置上有两子,加50分
						addScore(tempArr,points,tempX,tempY,50);
					}
					else if (num == 3) {//此获胜方式的五个位置上有三子,加200分
						addScore(tempArr,points,tempX,tempY,200);
					}
					else if (num == 4) {//此获胜方式的五个位置上有四子,加500分
						addScore(tempArr,points,tempX,tempY,500);
					}
					else{//
						//GameOver gameOver = new GameOver("恭喜你，取得胜利！");
					}
				}
			}
		}
	}
	
	//给某一点的权重加分
	 public void addScore(int[] tempArr,Point[][] points,int[] xArr,int[] yArr,int score)
	 {
		 for(int m = 0;m<5;m++)
			{
				if(tempArr[m] == 0)
				{
					points[xArr[m]][yArr[m]].setWright(score+points[xArr[m]][yArr[m]].getWright());
				}
			}
	 }
	
	//求某一数组中key值个数
	public static int searchKeyNum(int[] arr,int key)
	{
		int result = 0;
		for (int i = 0; i < arr.length; i++) {
			if(key == arr[i])
				result++;
		}
		return result;
	}
	
	//查找数组中最大的权值点
	public Point searchMaxWeight(Point[][] points)
	{
		Point maxpoint = new Point();
		maxpoint.setWright(-1);
		for(int i = 0; i < ROWS; i++)
		{
			for(int j = 0; j < ROWS; j++)
			{
				if(points[i][j]!=null)
				{
					if(points[i][j].getWright() > maxpoint.getWright())
						maxpoint = points[i][j];
				}
			}
		}
		return maxpoint;
	}
	
	//判断是否胜利
	public boolean isWin(int player)
	{
		boolean result = false;
		for (int k = 0; k < countWin; k++)
		{
			int[] tempArr = winTables[k].getIsH();
			int num = searchKeyNum(tempArr,player);
			if(num == 5)
				result = true;
		}
		return result;
	}
}