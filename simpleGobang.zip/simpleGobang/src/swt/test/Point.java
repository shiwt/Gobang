package swt.test;
//点类，记录点的坐标数据,和此点权重
public class Point {
	private int x;
	private int y;
	private int wright;
	public Point()
	{
		this.x = -1;
		this.y = -1;
		this.wright = 0;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWright() {
		return wright;
	}
	public void setWright(int wright) {
		this.wright = wright;
	}
	
}
